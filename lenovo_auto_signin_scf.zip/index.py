# -*- coding: utf8 -*-
import os
import requests
from bs4 import BeautifulSoup

PUSH_KEY = os.environ["PUSH_KEY"]
USERNAME = os.environ["USERNAME"]
PASSWORD = os.environ["PASSWORD"]

header_signin = {
    "user-agent": "Mozilla/5.0 (Linux; Android 11; Mi 10 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.185 Mobile Safari/537.36/lenovoofficialapp/16112154380982287_10181446134/newversion/versioncode-124/"
}
header_count = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.96 Safari/537.36",
}
header_login = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.96 Safari/537.36",
    "Host": "reg.lenovo.com.cn",
    "Referer": "https://www.lenovo.com.cn/"
}
data_login = {"account": USERNAME, "password": PASSWORD, "ticket": "e40e7004-4c8a-4963-8564-31271a8337d8"}

url_login = "https://reg.lenovo.com.cn/auth/v3/dologin"
url_count = "https://club.lenovo.com.cn/signlist/"
url_signin = "https://i.lenovo.com.cn/signIn/add.jhtml?sts=e40e7004-4c8a-4963-8564-31271a8337d8"
url_push = "https://sc.ftqq.com/%s.send" % PUSH_KEY

def run():
    s = requests.session()
    login = s.post(url_login,headers=header_login,data=data_login)
    if login.text.find("cerpreg-passport") == -1:
        return "登录失败"
    signin = s.get(url_signin,headers=header_signin)
    check = str(signin.text)
    if "true" in check:
        if "乐豆" in check:
            print("签到成功")
        else:
            print("请不要重复签到")
    else:
        print("签到失败，请重试")
        exit()
    count = s.get(url_count,headers=header_count)
    soup = BeautifulSoup(count.text,"html.parser")
    day = soup.select("body > div.signInMiddleWrapper > div > div.signInTimeInfo > div.signInTimeInfoMiddle > p.signInTimeMiddleBtn")
    day = day[0].get_text()
    print(day)
    push_data = {
        "text":"联想商城签到：%s"%day
    }
    requests.post(url_push,data=push_data)
    print(push_data)

run()